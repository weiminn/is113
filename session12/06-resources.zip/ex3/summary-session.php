<?php
    # Start a session
    
    # Echo name and age information
    echo "Name: ";
    echo "<br/>";
    echo "Age: ";
    echo "<br/>";
    
    echo "Hobby: " . $_POST["hobby"];
?>
