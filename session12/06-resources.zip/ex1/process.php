<?php
    # Obtain target location passed from index.html
    
    # Redirect to target location
    
    # Stop further execution
?>