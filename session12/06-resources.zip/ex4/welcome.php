<?php
    require_once "protect.php";
    echo "<h1>Welcome to Secure System</h1>";
?>
