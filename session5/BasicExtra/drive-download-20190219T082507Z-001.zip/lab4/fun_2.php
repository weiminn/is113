<?php

    // add your code here
    
?>


<form>

Enter an integer m: <input name="m" type="text">
<br/>
Enter another integer n: <input name="n" type="text">
<br/>

<input type="submit">

</form>