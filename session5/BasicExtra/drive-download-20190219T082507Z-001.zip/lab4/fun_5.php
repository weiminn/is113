<?php

    /*
    Define two functions called encode and decode. 
    The function encode takes in a string and returns the encoded string in hexadecimal format. 
    The function decode, on the other hand takes in the encoded string in hexadecimal format and returns the original string. 

    You can assume that the string passed into the function encode contains 
    only valid characters from a-z or A-Z and punctuation symbols. 
    You can also assume that a valid encoded string is passed into the function decode, i.e. every 2 characters represent the hexadecimal form corresponding to the original character. 
    */

    // Add your code here
    
?>


<form>

 <!-- Add your code here -->

</form>