<?php

 // add your code here
 
?>


<form>

Enter an integer n: <input name="n" type="text">
<br/>
Enter another integer f: <input name="f" type="text">
<br/>

<input type="submit">

</form>