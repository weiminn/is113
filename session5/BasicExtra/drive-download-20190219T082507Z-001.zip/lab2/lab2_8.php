<?php
    $count = $_GET["count"];
    $start = $_GET["start"];
    # Write code here

    # End of code
?>
