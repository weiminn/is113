<?php
    $amount = $_GET["amount"];
    # Write code here

    # End of code
    
?>