<?php
    $n = $_GET["number"];
      
    # Write code here

    # End of code

?>