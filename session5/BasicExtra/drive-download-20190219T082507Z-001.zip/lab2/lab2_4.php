<?php
    $binary_num = $_GET["binary_num"];
    # Write code here

    # End of code
?>