<?php
    $income = $_GET["income"];
    # Write code here

    # End of code
?>