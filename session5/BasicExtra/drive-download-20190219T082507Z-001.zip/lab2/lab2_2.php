<?php
$num1 = rand(1,10);
$num2 = rand(1,10);
$num3 = rand(1,10);
  
echo "*****************<br/>";
echo "** $num1 ** $num2 ** $num3 **<br/>";
echo "*****************</br>";
 
# Write code here

# End of code
?>
