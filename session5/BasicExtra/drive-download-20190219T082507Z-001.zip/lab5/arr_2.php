<?php

    /*
        arr_2.py contains a form that gets 10 integer inputs from the user. 
        It should then display the minimum, maximum and median of all numbers entered. 
    */

   // add your code here
?>


    <form>

    Enter 10 integers (separate each integer with a space): 
    <input name="numbers" type="text" placeholder="6 4 1 11 21 34 5 9 81 12">
    <br/>
   
    <input type="submit" value="Compute Stat">

    </form>