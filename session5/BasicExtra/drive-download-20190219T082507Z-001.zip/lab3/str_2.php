<?php

   // add your code here
 
?>


<form>

    Enter a line of text with email address : <input name="input" type="text" size="100">
    <br/>
   
    <input type="submit">
    
</form>