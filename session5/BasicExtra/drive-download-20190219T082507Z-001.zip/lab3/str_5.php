<?php

// add your code here


?>


<form>

Enter characters: <input name="str1" type="text">
<br/>
In string? : <input name="str2" type="text">
<br/>

<input type="submit">

</form>