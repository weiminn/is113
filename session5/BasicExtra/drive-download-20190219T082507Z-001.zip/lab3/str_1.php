<?php

    // add your code here


?>

<p>Please enter your name and gender.</p>

<form>

    Name: <input name="name" type="text"><br/>
    Gender
    <label for="male">Male</label> <input type="radio" name="gender" value="male" id="male">
    <label for="female">Female</label> <input type="radio" name="gender" value="female" id="female">
    <br/>
    <input type="submit">
    
</form>