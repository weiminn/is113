<?php

   // add your code here
 
?>


<form>

    Enter the string : <input name="string" type="text">
    <br/>
    
    <input type="submit">
    
</form>