


<?php

// add your code here


?>


<form>

Enter the string : <input name="text" type="text">
<br/>
Enter the start char : <input name="start" type="text">
<br/>
Enter the end char : <input name="end" type="text">
<br/>

<input type="submit">

</form>