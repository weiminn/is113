<?php
    $tempInF = $_GET["tempInF"];
    $tempInC = 0;

    # Write code here

    # End of code
    
    echo "$tempInF F = $tempInC C";
?>