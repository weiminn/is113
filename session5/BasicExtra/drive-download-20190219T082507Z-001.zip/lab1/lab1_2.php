<?php
$var = 60;
# Write code here

# End of code
?>