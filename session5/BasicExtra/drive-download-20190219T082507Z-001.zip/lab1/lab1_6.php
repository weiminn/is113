<?php
    $prev_balance = $_GET['prev_balance'];
    $paid_amount = $_GET['paid_amount'];
    $day_payment_made = $_GET['day_payment_made'];
    $interest_rate = $_GET['interest_rate'];

    # Write code here

    # End of code

?>