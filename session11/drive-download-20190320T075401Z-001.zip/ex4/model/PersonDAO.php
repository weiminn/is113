<?php
    class PersonDAO{
        public function retrieveAll(){
            //Add code here to return an array of Person objects
        }
        public function add($person) {//$person must be an object of class Person
            //Add code here
        }
    }
?>