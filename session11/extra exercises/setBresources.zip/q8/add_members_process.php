<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
</head> 
<body>
	
	<h1>[Club Name]</h1>
	<p> 
		Back to club | Add more members
	</p>
	<p class='highlight'>
        No one selected
		Lee Yong Zhang, Kim Yong Jun added!
	</p>
	
	<?php
	include 'footer.php';
	?>
	
</body>
</html>
