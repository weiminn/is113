<?php
/* 
    Name:  
    Email: 
*/
?>
<html>
<body>
    <?php
    ?>
    <form method='post' action='q2-one.php'>
        <input type="checkbox" value="apple" name="fruit[]">Apple
        <input type="checkbox" value="orange" name="fruit[]">Orange
        <input type="checkbox" value="pear" name="fruit[]">Pear
        <br>
        <input type='submit' name='send'>
    </form>
</body>
</html>