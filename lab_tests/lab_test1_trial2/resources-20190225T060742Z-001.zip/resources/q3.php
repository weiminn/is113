<?php
/* 
    Name:  
    Email: 
*/

$people = [
    "trump"    => 'Donald Trump',
    "clinton"  => 'Hillary Clinton',
    "kim"      => 'Kim Jong Un',
    "moon"     => 'Moon Jae In',
    "putin"    => 'Vladimir Putin'
];

?>
<!DOCTYPE html>
<html>
<body>
    <form method='post' action='q3.php'>
        
    </form>
</body>
</html>